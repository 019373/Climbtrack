import path from 'path';
import react from '@vitejs/plugin-react';
import tailwindcss from '@tailwindcss/vite';
import { defineConfig } from 'vite';
import { VitePWA } from 'vite-plugin-pwa';

import runtimeErrorOverlay from '@replit/vite-plugin-runtime-error-modal';

const parsedPort = Number(
  process.env.PORT ?? '5173',
);

const port =
  Number.isFinite(parsedPort) &&
  parsedPort > 0
    ? parsedPort
    : 5173;

const basePath =
  process.env.BASE_PATH ?? '/';

export default defineConfig({
  base: basePath,

  plugins: [
    react(),

    tailwindcss(),

    runtimeErrorOverlay(),

    VitePWA({
      registerType: 'autoUpdate',

      includeAssets: [
        'icons/icon-512.png',
      ],

      workbox: {
        globPatterns: [
          '**/*.{js,css,html,ico,png,svg}',
        ],
      },

      manifest: {
        name: 'ClimbTrack',
        short_name: 'ClimbTrack',

        description:
          'Application de suivi d’entraînement pour l’escalade et la préparation physique.',

        theme_color: '#000000',
        background_color: '#000000',

        display: 'standalone',
        orientation: 'portrait',

        icons: [
          {
            src: 'icons/icon-512.png',
            sizes: '512x512',
            type: 'image/png',
            purpose: 'any',
          },
          {
            src: 'icons/icon-512.png',
            sizes: '512x512',
            type: 'image/png',
            purpose: 'maskable',
          },
        ],
      },
    }),

    ...(process.env.NODE_ENV !==
      'production' &&
    process.env.REPL_ID !==
      undefined
      ? [
          await import(
            '@replit/vite-plugin-cartographer'
          ).then((m) =>
            m.cartographer({
              root: path.resolve(
                import.meta.dirname,
                '..',
              ),
            }),
          ),

          await import(
            '@replit/vite-plugin-dev-banner'
          ).then((m) =>
            m.devBanner(),
          ),
        ]
      : []),
  ],

  resolve: {
    alias: {
      '@': path.resolve(
        import.meta.dirname,
        'src',
      ),

      '@assets': path.resolve(
        import.meta.dirname,
        '..',
        '..',
        'attached_assets',
      ),
    },

    dedupe: [
      'react',
      'react-dom',
    ],
  },

  root: path.resolve(
    import.meta.dirname,
  ),

  build: {
    outDir: path.resolve(
      import.meta.dirname,
      'dist/public',
    ),

    emptyOutDir: true,
  },

  server: {
    port,

    strictPort: true,

    host: '0.0.0.0',

    allowedHosts: true,

    fs: {
      strict: true,
    },
  },

  preview: {
    port,

    host: '0.0.0.0',

    allowedHosts: true,
  },
});